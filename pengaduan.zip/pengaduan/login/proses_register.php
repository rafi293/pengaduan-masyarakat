<?php
include '../koneksi.php';

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $nama = $_POST['nama_lengkap'];
    $level = $_POST['level'];

    // Cek apakah username sudah ada
    $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $check->bind_param("s", $username);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        session_start();
        $_SESSION['register_error'] = "Username sudah terdaftar!";
        header("Location: register.php");
        exit();
    } else {
        // Enkripsi password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Simpan data
        $stmt = $conn->prepare("INSERT INTO users (username, password, nama_lengkap, level) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $username, $hashed_password, $nama, $level);

        if ($stmt->execute()) {
            session_start();
            $_SESSION['register_success'] = true;
            header("Location: login.php");
            exit();
        } else {
            session_start();
            $_SESSION['register_error'] = "Registrasi gagal!";
            header("Location: register.php");
            exit();
        }
    }
}

<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Pengaduan Masyarakat</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/style_login_register.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <i class="fas fa-exclamation-triangle logo"></i>
            <h1>Login Pengaduan</h1>
            <p>Masukkan akun Anda untuk mengakses sistem</p>
        </div>

        <?php if (isset($_SESSION['register_success'])): ?>
            <div class="alert alert-success">
                Registrasi berhasil! Silakan login.
            </div>
            <?php unset($_SESSION['register_success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['login_error'])): ?>
            <div class="alert alert-danger">
                <?= $_SESSION['login_error']; ?>
            </div>
            <?php unset($_SESSION['login_error']); ?>
        <?php endif; ?>

        <form method="POST" class="form-login" action="proses_login.php">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" name="login" class="btn-login">Masuk</button>
        </form>

        <div class="footer">
            <p>Belum punya akun? <a href="register.php">Daftar disini</a></p>
            <p class="copyright">© <?= date('Y'); ?> Sistem Pengaduan Masyarakat</p>
        </div>
    </div>
</body>
</html>

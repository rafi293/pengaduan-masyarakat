<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - Sistem Pengaduan Masyarakat</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/style_login_register.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <i class="fas fa-exclamation-triangle logo"></i>
            <h1>Pendaftaran Akun</h1>
            <p>Buat akun baru untuk mengajukan pengaduan</p>
        </div>

        <?php if (isset($_SESSION['register_error'])): ?>
            <div class="alert alert-danger">
                <?= $_SESSION['register_error']; ?>
            </div>
            <?php unset($_SESSION['register_error']); ?>
        <?php endif; ?>

        <form method="POST" class="form-register" action="proses_register.php">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="nama_lengkap" placeholder="Nama Lengkap" required>
            </div>
            <div class="input-group">
                <i class="fas fa-at"></i>
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="input-group">
                <i class="fas fa-user-tag"></i>
                <select name="level" required>
                    <option value="user">User</option>
                    <option value="admin">Admin</option> <!-- Batasi di sisi backend -->
                </select>
            </div>
            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" name="register" class="btn-register">Daftar Sekarang</button>
        </form>

        <div class="footer">
            <p>Sudah punya akun? <a href="login.php">Login disini</a></p>
            <p class="copyright">© <?= date('Y'); ?> Sistem Pengaduan Masyarakat</p>
        </div>
    </div>
</body>
</html>

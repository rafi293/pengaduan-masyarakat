<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengaduan Masyarakat - Desa Suwayuwo</title>
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="header-container">
            <div class="header-content">
                <div class="logo-container">
                    <img src="images/logo.png" alt="Logo Desa" class="logo">
                    <div class="title-container">
                        <h1>Sistem Pengaduan Masyarakat</h1>
                        <p class="subtitle">Desa Suwayuwo • Kabupaten Pasuruan</p>
                    </div>
                </div>
                <nav class="nav-menu">
                    <ul>
                        <li><a href="index.php"><i class="fas fa-home"></i> Beranda</a></li>
                        <li><a href="login/login.php"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                        <li><a href="#"><i class="fas fa-info-circle"></i> Tentang</a></li>
                        <li><a href="#"><i class="fas fa-phone-alt"></i> Kontak</a></li>
                    </ul>
                </nav>
            </div>
        </div>
        <div class="header-wave">
            <svg viewBox="0 0 1200 120" preserveAspectRatio="none">
                <path d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" opacity=".25" fill="#228B22"></path>
                <path d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z" opacity=".5" fill="#228B22"></path>
                <path d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z" fill="#228B22"></path>
            </svg>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-image">
            <img src="images/balai_desa.jpg" alt="Balai Desa Suwayuwo" class="main-image">
            <div class="image-overlay"></div>
        </div>
        <div class="hero-content">
            <h2>Selamat Datang di Layanan Pengaduan Online</h2>
            <p>Website ini dibuat untuk mempermudah masyarakat Desa Suwayuwo dalam menyampaikan pengaduan atau laporan secara online.</p>
            <a href="login/login.php" class="cta-button">Buat Pengaduan <i class="fas fa-arrow-right"></i></a>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features">
        <div class="feature-card">
            <i class="fas fa-clock"></i>
            <h3>Cepat</h3>
            <p>Pengaduan Anda akan segera diproses dalam waktu 1x24 jam</p>
        </div>
        <div class="feature-card">
            <i class="fas fa-shield-alt"></i>
            <h3>Aman</h3>
            <p>Data dan identitas Anda terlindungi dengan baik</p>
        </div>
        <div class="feature-card">
            <i class="fas fa-check-circle"></i>
            <h3>Transparan</h3>
            <p>Anda dapat melacak status pengaduan kapan saja</p>
        </div>
    </section>

    <!-- Documentation Section -->
    <section class="documentation">
        <h2>Dokumentasi Desa</h2>
        <div class="photo-gallery">
            <div class="photo-item">
                <img src="images/gotong_royong.jpg" alt="Kegiatan Desa">
                <div class="photo-caption">
                    <p>Kegiatan gotong royong membersihkan lingkungan desa</p>
                </div>
            </div>
            <div class="photo-item">
                <img src="images/fasilitas_umum.png" alt="Fasilitas Desa">
                <div class="photo-caption">
                    <p>Fasilitas umum yang telah dibangun tahun 2023</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>Kontak Kami</h3>
                <p><i class="fas fa-map-marker-alt"></i> Balai Desa Suwayuwo, Kecamatan Sukorejo, Kabupaten Pasuruan</p>
                <p><i class="fas fa-phone"></i>  0812-3456-7890</p>
                <p><i class="fas fa-envelope"></i> Kantorsuwayuwo@gmail.com</p>
            </div>
            <div class="footer-section">
                <h3>Jam Operasional</h3>
                <p>Senin - Jumat: 08.00 - 16.00 WIB</p>
                <p>Sabtu: 08.00 - 14.00 WIB</p>
                <p>Minggu & Hari Libur: Tutup</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p> Website Pengaduan Masyarakat - Desa Suwayuwo</p>
        </div>
    </footer>

    <script src="js/script.js"></script>
</body>
</html>
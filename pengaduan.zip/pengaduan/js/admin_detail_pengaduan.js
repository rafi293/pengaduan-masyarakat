 // Form validation
    const responseForm = document.querySelector('.response-form');
    if (responseForm) {
        responseForm.addEventListener('submit', function(e) {
            const textarea = this.querySelector('textarea');
            if (textarea.value.trim().length < 10) {
                e.preventDefault();
                alert('Tanggapan harus minimal 10 karakter');
                textarea.focus();
            }
        });
    }

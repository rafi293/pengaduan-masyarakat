document.addEventListener('DOMContentLoaded', function() {
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Form submission handling
    const form = document.querySelector('.pengaduan-form form');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Here you would typically send the form data to a server
            // For demonstration, we'll just show an alert
            alert('Pengaduan Anda telah berhasil dikirim! Terima kasih atas partisipasinya.');
            form.reset();
        });
    }
    
    // Add hover effect to photo items
    const photoItems = document.querySelectorAll('.photo-item');
    photoItems.forEach(item => {
        const img = item.querySelector('img');
        const caption = item.querySelector('.photo-caption');
        
        item.addEventListener('mouseenter', () => {
            caption.style.opacity = '1';
            caption.style.transform = 'translateY(0)';
        });
        
        item.addEventListener('mouseleave', () => {
            caption.style.opacity = '0';
            caption.style.transform = 'translateY(20px)';
        });
    });
});
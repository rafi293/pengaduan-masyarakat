<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['level'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

include '../koneksi.php';

// Get all reports
$query = "SELECT p.*, u.nama_lengkap FROM pengaduan p 
          JOIN users u ON p.user_id = u.id 
          ORDER BY p.tanggal_lapor DESC
          LIMIT 5";

$result = mysqli_query($conn, $query) or die("Query error: " . mysqli_error($conn));

// Get statistics
$stats_query = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'menunggu' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN status = 'diproses' THEN 1 ELSE 0 END) as proses,
    SUM(CASE WHEN status = 'selesai' THEN 1 ELSE 0 END) as selesai
    FROM pengaduan";
$stats_result = mysqli_query($conn, $stats_query);
$stats = mysqli_fetch_assoc($stats_result);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Dashboard Admin - SUWAYUWO</title>
    <link rel="stylesheet" href="../assets/admin_dashboard.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>SUWAYUWO</h2>
                <p>Admin Panel</p>
            </div>
            <nav class="sidebar-menu">
                <a href="#" class="active"><i class="fas fa-home"></i> Dashboard</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="content-header">
                <h1>Dashboard Admin</h1>
                <div class="user-info">
                    <span><?php echo htmlspecialchars($_SESSION['nama']); ?></span>
                </div>
            </header>

            <!-- Statistics Section -->
            <section class="stats-section">
                <div class="stat-card">
                    <div class="stat-icon total">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Total Pengaduan</h3>
                        <p><?php echo $stats['total']; ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon pending">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Pending</h3>
                        <p><?php echo $stats['pending']; ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon proses">
                        <i class="fas fa-spinner"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Diproses</h3>
                        <p><?php echo $stats['proses']; ?></p>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon selesai">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Selesai</h3>
                        <p><?php echo $stats['selesai']; ?></p>
                    </div>
                </div>
            </section>

            <!-- Recent Complaints Section -->
            <section class="recent-complaints">
                <div class="section-header">
                    <h2>Pengaduan Terbaru</h2>
                    <a href="detail_pengaduan.php" class="btn-view-all">Lihat Semua</a>
                </div>

                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Pelapor</th>
                                <th>Judul</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($result) > 0): ?>
                                <?php $no = 1; while ($row = mysqli_fetch_assoc($result)): ?>
                                    <?php 
                                        $status = strtolower(trim($row['status']));
                                        // Normalize status for CSS class
                                        $status_class = $status;
                                        if ($status == 'proses' || $status == 'processed') {
                                            $status_class = 'diproses';
                                        }
                                    ?>
                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_lengkap']); ?></td>
                                        <td><?php echo htmlspecialchars($row['judul']); ?></td>
                                        <td><?php echo date('d M Y', strtotime($row['tanggal_lapor'])); ?></td>
                                        <td>
                                            <span class="status-badge <?php echo $status_class; ?>" title="Status: <?php echo $status; ?>">
                                                <?php echo ucfirst($status_class); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="detail_pengaduan.php?id=<?php echo $row['id_pengaduan']; ?>" 
                                               class="btn-view" 
                                               title="Lihat Detail">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="no-data">
                                        <i class="fas fa-info-circle"></i> Belum ada pengaduan
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>

    <script>
        function updateTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString('id-ID');
            const dateString = now.toLocaleDateString('id-ID', { 
                weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' 
            });
            document.querySelector('.content-header h1').innerHTML = 
                `Dashboard Admin <small>${dateString} ${timeString}</small>`;
        }
        setInterval(updateTime, 1000);
        updateTime();
    </script>
</body>
</html>
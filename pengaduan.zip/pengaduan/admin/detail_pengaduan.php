<?php
session_start();

if (!isset($_SESSION['level']) || $_SESSION['level'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

require '../koneksi.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    header("Location: dashboard.php?error=invalid_id");
    exit();
}

$stmt = $conn->prepare("SELECT p.*, u.nama_lengkap FROM pengaduan p 
                        JOIN users u ON p.user_id = u.id 
                        WHERE p.id_pengaduan = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$pengaduan = $result->fetch_assoc();

if (!$pengaduan) {
    header("Location: dashboard.php?error=not_found");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <a href="dashboard.php" style="display: inline-block; padding: 8px 16px; background-color: #007BFF; color: white; text-decoration: none; border-radius: 4px;">&larr; Kembali ke Dashboard</a>
    <title>Detail Laporan</title>
    <link rel="stylesheet" href="../assets/admin_detail_pengaduan.css">
</head>
<body>
    <h2>Detail Laporan</h2>

    <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
        <p class="success">Status berhasil diperbarui.</p>
    <?php elseif (isset($_GET['error'])): ?>
        <p class="error"><?= $_GET['error'] === 'invalid_status' ? "Status tidak valid." : "Terjadi kesalahan."; ?></p>
    <?php endif; ?>

    <div class="box">
        <p><span class="label">Judul:</span> <?= htmlspecialchars($pengaduan['judul']) ?></p>
        <p><span class="label">Nama Pelapor:</span> <?= htmlspecialchars($pengaduan['nama_lengkap']) ?></p>
        <p><span class="label">Tanggal Lapor:</span> <?= date('d M Y H:i', strtotime($pengaduan['tanggal_lapor'])) ?></p>
        <p><span class="label">Isi Laporan:</span><br><?= nl2br(htmlspecialchars($pengaduan['isi_laporan'])) ?></p>
        <p><span class="label">Status Saat Ini:</span> <strong><?= htmlspecialchars($pengaduan['status']) ?></strong></p>
    </div>

    <h3>Beri Tanggapan</h3>
    <form method="post" action="proses_detail_pengaduan.php">
        <input type="hidden" name="aksi" value="tanggapan">
        <input type="hidden" name="id" value="<?= $pengaduan['id_pengaduan'] ?>">
        <textarea name="isi_tanggapan" rows="4" cols="50" required></textarea><br><br>
        <button type="submit">Kirim Tanggapan</button>
    </form>

    <h3>Ubah Status</h3>
    <form method="post" action="proses_detail_pengaduan.php">
        <input type="hidden" name="aksi" value="ubah_status">
        <input type="hidden" name="id" value="<?= $pengaduan['id_pengaduan'] ?>">
        <select name="status" required>
            <option value="menunggu" <?= $pengaduan['status'] == 'menunggu' ? 'selected' : '' ?>>Menunggu</option>
            <option value="diproses" <?= $pengaduan['status'] == 'diproses' ? 'selected' : '' ?>>Diproses</option>
            <option value="selesai" <?= $pengaduan['status'] == 'selesai' ? 'selected' : '' ?>>Selesai</option>
            <option value="dihapus">Hapus Sekarang</option>
        </select><br><br>
        <button type="submit">Perbarui Status</button>
    </form>
</body>
</html>

<?php
session_start();
require '../koneksi.php';

if (!isset($_SESSION['level']) || $_SESSION['level'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: dashboard.php");
    exit();
}

$aksi = $_POST['aksi'] ?? '';
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$id) {
    header("Location: dashboard.php?error=invalid_id");
    exit();
}

if ($aksi === 'ubah_status') {
    $status = $_POST['status'];
    if (!in_array($status, ['menunggu', 'diproses', 'selesai', 'dihapus'])) {
        header("Location: detail_pengaduan.php?id=$id&error=invalid_status");
        exit();
    }

    if ($status === 'dihapus') {
        $stmt = $conn->prepare("DELETE FROM pengaduan WHERE id_pengaduan = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        header("Location: dashboard.php?success=deleted");
        exit();
    } else {
        $up = $conn->prepare("UPDATE pengaduan SET status = ? WHERE id_pengaduan = ?");
        $up->bind_param("si", $status, $id);
        $up->execute();

        header("Location: detail_pengaduan.php?id=$id&success=1");
        exit();
    }
} elseif ($aksi === 'tanggapan') {
    $isi = trim($_POST['isi_tanggapan']);
    $admin_id = $_SESSION['id'];

    if ($isi !== '') {
        $stmt = $conn->prepare("INSERT INTO tanggapan (id_pengaduan, admin_id, isi_tanggapan) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $id, $admin_id, $isi);
        $stmt->execute();
        header("Location: detail_pengaduan.php?id=$id&success=tanggapan");
        exit();
    } else {
        header("Location: detail_pengaduan.php?id=$id&error=empty_tanggapan");
        exit();
    }
}

// fallback redirect
header("Location: detail_pengaduan.php?id=$id");
exit();
?>

<?php
// Mulai session
session_start();

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['level']) || $_SESSION['level'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// Termasuk file koneksi ke database
include '../includes/koneksi.php';

// Cek apakah ID pengaduan ada di query string
if (isset($_GET['id'])) {
    $id_pengaduan = $_GET['id'];

    // Buat query untuk menghapus pengaduan berdasarkan ID
    $query = "DELETE FROM pengaduan WHERE id_pengaduan = ?";

    // Persiapkan query
    if ($stmt = mysqli_prepare($conn, $query)) {
        // Bind parameter (ID pengaduan)
        mysqli_stmt_bind_param($stmt, "i", $id_pengaduan);

        // Eksekusi query
        if (mysqli_stmt_execute($stmt)) {
            // Jika berhasil, alihkan ke halaman dengan pesan sukses
            header("Location: dashboard.php?pesan=berhasil_hapus");
        } else {
            // Jika gagal, tampilkan pesan error
            echo "Gagal menghapus pengaduan.";
        }

        // Tutup prepared statement
        mysqli_stmt_close($stmt);
    } else {
        echo "Gagal mempersiapkan query.";
    }
} else {
    echo "ID pengaduan tidak ditemukan.";
}

// Tutup koneksi database
mysqli_close($conn);
?>

<?php
$host = "localhost";        // Nama host (biasanya localhost)
$user = "root";             // Username MySQL (default: root)
$pass = "";                 // Password MySQL (default: kosong)
$db   = "pengaduan_masyarakat"; // Nama database

// Membuat koneksi
$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}
?>

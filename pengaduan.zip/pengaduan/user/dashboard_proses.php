<?php
session_start();

// Validasi session dan user
if (!isset($_SESSION['level']) || $_SESSION['level'] != 'user') {
    header("Location: ../login.php");
    exit;
}
if (!isset($_SESSION['user_id'], $_SESSION['nama'])) {
    header("Location: ../login.php");
    exit;
}

include '../koneksi.php';

$user_id = $_SESSION['user_id'];
$stats = ['menunggu' => 0, 'diproses' => 0, 'selesai' => 0];
$complaints = [];

try {
    $conn->autocommit(FALSE);
    
    // Ambil statistik pengaduan
    $stmt_stats = $conn->prepare("SELECT 
        COUNT(CASE WHEN status = 'menunggu' THEN 1 END) as menunggu,
        COUNT(CASE WHEN status = 'diproses' THEN 1 END) as diproses,
        COUNT(CASE WHEN status = 'selesai' THEN 1 END) as selesai
        FROM pengaduan WHERE user_id = ?");
    $stmt_stats->bind_param("i", $user_id);
    $stmt_stats->execute();
    $stats_result = $stmt_stats->get_result();
    $stats = $stats_result->fetch_assoc();
    $stmt_stats->close();
    
    // Ambil data pengaduan user
    $stmt_complaints = $conn->prepare("SELECT * FROM pengaduan WHERE user_id = ? ORDER BY tanggal_lapor DESC");
    $stmt_complaints->bind_param("i", $user_id);
    $stmt_complaints->execute();
    $result = $stmt_complaints->get_result();
    $complaints = $result->fetch_all(MYSQLI_ASSOC);
    $stmt_complaints->close();
    
    $conn->commit();
} catch (Exception $e) {
    $conn->rollback();
    error_log("Database error: " . $e->getMessage());
} finally {
    $conn->autocommit(TRUE);
    $conn->close();
}

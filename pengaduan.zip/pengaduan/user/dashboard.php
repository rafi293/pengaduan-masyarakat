<?php
include 'dashboard_proses.php'; // load data dan session validasi
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Dashboard Pengguna - SIPEMAS</title>
    <link rel="stylesheet" href="../assets/user_dashboard.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>SUWAYUWO</h2>
                <p>Sistem Pengaduan Masyarakat</p>
            </div>
            <div class="user-profile">
                <h3><?= htmlspecialchars($_SESSION['nama']); ?></h3>
                <p>Pengguna</p>
            </div>
            <nav class="sidebar-menu">
                <a href="#" class="active"><i class="fas fa-home"></i> Dashboard</a>
                <a href="buat_pengaduan.php"><i class="fas fa-plus-circle"></i> Buat Pengaduan</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
            <div class="help-section">
                <h4>Butuh Bantuan?</h4>
                <p>Hubungi kami di:</p>
                <p><i class="fas fa-phone"></i> 0812-3456-7890</p>
                <p><i class="fas fa-envelope"></i> Kantorsuwayuwo@gmail.com</p>
            </div>
        </aside>
        <main class="main-content">
            <header class="content-header">
                <h1>Selamat Datang, <?= htmlspecialchars($_SESSION['nama']); ?></h1>
                <div class="date-time">
                    <span id="current-date"></span>
                    <span id="current-time"></span>
                </div>
            </header>

            <section class="stats-section">
                <div class="stat-card menunggu">
                    <div class="stat-icon"><i class="fas fa-inbox"></i></div>
                    <div class="stat-info">
                        <h3>Menunggu</h3>
                        <p><?= htmlspecialchars($stats['menunggu'] ?? 0); ?></p>
                    </div>
                </div>
                <div class="stat-card diproses">
                    <div class="stat-icon"><i class="fas fa-spinner"></i></div>
                    <div class="stat-info">
                        <h3>Diproses</h3>
                        <p><?= htmlspecialchars($stats['diproses'] ?? 0); ?></p>
                    </div>
                </div>
                <div class="stat-card selesai">
                    <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                    <div class="stat-info">
                        <h3>Selesai</h3>
                        <p><?= htmlspecialchars($stats['selesai'] ?? 0); ?></p>
                    </div>
                </div>
            </section>

            <section class="recent-complaints">
                <h2>Pengaduan Terakhir</h2>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Judul Pengaduan</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                                <th>Lihat Detail</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($complaints)): ?>
                                <?php foreach ($complaints as $index => $data): ?>
                                    <tr>
                                        <td><?= $index + 1; ?></td>
                                        <td><?= htmlspecialchars($data['judul']); ?></td>
                                        <td><?= date('d M Y', strtotime($data['tanggal_lapor'])); ?></td>
                                        <td>
                                            <span class="status-badge <?= htmlspecialchars($data['status']); ?>">
                                                <?= ucfirst(htmlspecialchars($data['status'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="detail_pengaduan.php?id=<?= $data['id_pengaduan']; ?>" class="btn-detail">
                                                <i class="fas fa-eye"></i> Detail
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="no-data">
                                        <i class="fas fa-info-circle"></i> Belum ada pengaduan
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>

    <script>
        function updateDateTime() {
            const now = new Date();
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('current-date').textContent = now.toLocaleDateString('id-ID', options);
            document.getElementById('current-time').textContent = now.toLocaleTimeString('id-ID');
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);
    </script>
</body>
</html>

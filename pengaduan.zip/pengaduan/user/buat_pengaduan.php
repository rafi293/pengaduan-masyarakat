<?php
session_start();

if (!isset($_SESSION['level']) || $_SESSION['level'] != 'user') {
    header("Location: ../login.php");
    exit;
}

// Ambil pesan error atau success dari session
$error = $_SESSION['error'] ?? null;
$success = $_SESSION['success'] ?? null;

// Hapus pesan setelah ditampilkan
unset($_SESSION['error'], $_SESSION['success']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Buat Pengaduan - SIPEMAS</title>
    <link rel="stylesheet" href="../assets/user_buat_pengaduan.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
</head>
<body>
    <div class="form-container">
        <div class="form-header">
            <a href="dashboard.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h1>Buat Pengaduan Baru</h1>
        </div>

        <?php if ($error): ?>
            <div class="alert error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="post" action="buat_pengaduan_proses.php" enctype="multipart/form-data" class="pengaduan-form">
            <div class="form-group">
                <label for="judul">Judul Pengaduan</label>
                <input type="text" name="judul" id="judul" placeholder="Masukkan judul pengaduan" required>
            </div>

            <div class="form-group">
                <label for="isi_laporan">Isi Laporan</label>
                <textarea name="isi_laporan" id="isi_laporan" rows="6" placeholder="Jelaskan pengaduan Anda secara detail" required></textarea>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-submit">
                    <i class="fas fa-paper-plane"></i> Kirim Pengaduan
                </button>
            </div>
        </form>
    </div>
</body>
</html>

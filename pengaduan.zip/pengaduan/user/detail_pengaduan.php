<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

$id_pengaduan = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$user_id = (int)$_SESSION['user_id'];

if ($id_pengaduan <= 0) {
    echo "ID pengaduan tidak valid.";
    exit;
}

$stmt = $conn->prepare("SELECT * FROM pengaduan WHERE id_pengaduan = ? AND user_id = ?");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("ii", $id_pengaduan, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    die("Query error: " . $conn->error);
}

$data = $result->fetch_assoc();

if (!$data) {
    echo "Data pengaduan tidak ditemukan.";
    exit;
}

$tanggapan = null;
$tanggapanQuery = "SELECT * FROM tanggapan WHERE id_pengaduan = '$id_pengaduan'";
$tanggapanResult = mysqli_query($conn, $tanggapanQuery);

if ($tanggapanResult && mysqli_num_rows($tanggapanResult) > 0) {
    $tanggapan = mysqli_fetch_assoc($tanggapanResult);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Pengaduan</title>
    <link rel="stylesheet" href="../assets/user_dashboard.css">
    <link rel="stylesheet" href="../assets/detail_pengaduan.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>SUWAYUWO</h2>
                <p>Sistem Pengaduan Masyarakat</p>
            </div>
            <div class="user-profile">
                <h3><?= htmlspecialchars($_SESSION['nama']); ?></h3>
                <p>Pengguna</p>
            </div>
            <nav class="sidebar-menu">
                <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
                <a href="buat_pengaduan.php"><i class="fas fa-plus-circle"></i> Buat Pengaduan</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
            <div class="help-section">
                <h4>Butuh Bantuan?</h4>
                <p><i class="fas fa-phone"></i> 0812-3456-7890</p>
                <p><i class="fas fa-envelope"></i> Kantorsuwayuwo@gmail.com</p>
            </div>
        </aside>

        <main class="main-content">
            <div class="detail-container">
                <div class="detail-header">
                    <h2>Detail Pengaduan</h2>
                </div>

                <div class="detail-item"><strong>Judul:</strong> <?= htmlspecialchars($data['judul']); ?></div>
                <div class="detail-item"><strong>Tanggal Lapor:</strong> <?= date('d M Y', strtotime($data['tanggal_lapor'])); ?></div>
                <div class="detail-item"><strong>Isi Laporan:</strong><br><?= nl2br(htmlspecialchars($data['isi_laporan'])); ?></div>
                <div class="detail-item"><strong>Status:</strong>
                    <span class="status-badge <?= htmlspecialchars($data['status']); ?>">
                        <?= ucfirst(htmlspecialchars($data['status'])); ?>
                    </span>
                </div>
                <?php if (!empty($data['foto']) && file_exists("../uploads/" . $data['foto'])): ?>
                    <div class="detail-item">
                        <strong>Foto:</strong><br>
                        <img src="../uploads/<?= htmlspecialchars($data['foto']); ?>" width="300" alt="Foto Pengaduan">
                    </div>
                <?php endif; ?>

                <?php if ($tanggapan): ?>
                    <div class="tanggapan-box">
                        <h3>Tanggapan Admin</h3>
                        <p><strong>Tanggal:</strong> <?= date('d M Y', strtotime($tanggapan['tanggal_tanggapan'])); ?></p>
                        <p><?= nl2br(htmlspecialchars($tanggapan['isi_tanggapan'])); ?></p>
                    </div>
                <?php else: ?>
                    <div class="tanggapan-box">
                        <h3>Tanggapan Admin</h3>
                        <p><i class="fas fa-info-circle"></i> Belum ada tanggapan dari admin.</p>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>

<?php
// Mulai sesi jika dibutuhkan
session_start();

// Panggil koneksi database
include '../koneksi.php';

// Cek apakah parameter ID tersedia
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk mengubah status menjadi 'dihapus'
    $query = "UPDATE pengaduan SET status = 'dihapus' WHERE id_pengaduan = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        // Redirect ke halaman sebelumnya atau halaman dashboard
        header("Location: admin/dashboard.php?pesan=hapus_berhasil");
    } else {
        echo "Gagal menghapus pengaduan.";
    }

    $stmt->close();
} else {
    echo "ID pengaduan tidak ditemukan.";
}
?>
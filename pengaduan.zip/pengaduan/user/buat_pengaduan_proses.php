<?php
session_start();

if (!isset($_SESSION['level']) || $_SESSION['level'] != 'user') {
    header("Location: ../login.php");
    exit;
}

include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $isi_laporan = mysqli_real_escape_string($conn, $_POST['isi_laporan']);
    $status = 'menunggu';

    $query = "INSERT INTO pengaduan (user_id, judul, isi_laporan, status, tanggal_lapor) 
              VALUES ('$user_id', '$judul', '$isi_laporan', '$status', NOW())";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $_SESSION['success'] = 'Pengaduan berhasil dikirim!';
        header("Location: dashboard.php");
        exit;
    } else {
        $_SESSION['error'] = 'Gagal mengirim pengaduan: ' . mysqli_error($conn);
        header("Location: buat_pengaduan.php");
        exit;
    }
} else {
    header("Location: buat_pengaduan.php");
    exit;
}
